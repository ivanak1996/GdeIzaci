﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

/// <summary>
/// Autor: Luka Klar 0508/15
/// </summary>

namespace GdeIzaci.ActionFilters
{
    public class AuthorizeRegistrationAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// AuthorizeRegistrationAttribute - klasa za validaciju prava pristupa neprijavljenog korisnika pri registraciji
        /// 
        /// @version 1.0
        /// </summary>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            Models.User user = filterContext.HttpContext.Session["TempUser"] as Models.User;

            if (user == null)
            {
                RouteValueDictionary redirectTargetDictionary = new RouteValueDictionary();
                redirectTargetDictionary.Add("action", "Index");
                redirectTargetDictionary.Add("controller", "Home");
                redirectTargetDictionary.Add("area", "");

                filterContext.Result = new RedirectToRouteResult(redirectTargetDictionary);
            }

            base.OnActionExecuting(filterContext);
        }
    }
}