﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

/// <summary>
/// Autor: Luka Klar 0508/15
/// </summary>

namespace GdeIzaci.ActionFilters
{
    /// <summary>
    /// AuthorizeNotLoggedInUser - klasa za validaciju prava pristupa neprijavljenog korisnika
    /// 
    /// @version 1.0
    /// </summary>
    public class AuthorizeNotLoggedInUser : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            Models.User user = filterContext.HttpContext.Session["User"] as Models.User;

            if (user != null)
            {
                RouteValueDictionary redirectTargetDictionary = new RouteValueDictionary();
                redirectTargetDictionary.Add("action", "Index");
                redirectTargetDictionary.Add("controller", "Home");
                redirectTargetDictionary.Add("area", "");

                filterContext.Result = new RedirectToRouteResult(redirectTargetDictionary);
            }

            base.OnActionExecuting(filterContext);
        }
    }
}