namespace GdeIzaci.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Reservation")]
    public partial class Reservation
    {
        public Guid Id { get; set; }

        public int UserId { get; set; }

        public int OfferId { get; set; }

        public virtual Offer Offer { get; set; }

        public virtual User User { get; set; }
    }
}
