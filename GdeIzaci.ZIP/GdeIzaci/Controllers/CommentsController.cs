﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

/// <summary>
/// Autori: Luka Klar 0508/15, Ivana Krstic 0362/15
/// </summary>

namespace GdeIzaci.Controllers
{
    /// <summary>
    /// EventsController - klasa za dodavanje/izmenu/brisanje komentara
    /// 
    /// @version 1.0
    /// </summary>
    public class CommentsController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        /// <summary>
        /// Kreira novi objekat komentara u bazi podataka
        /// </summary>
        /// <param name="comment"></param>
        /// <returns>Vraca na detalje lokala za koji je dodat komentar</returns>
        // POST: Comments/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [AuthorizeLoggedInUser]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,UserId,LocaleId,TimePublished,Text")] Comment comment)
        {
            if (ModelState.IsValid)
            {
                db.Comments.Add(comment);
                db.SaveChanges();
            }
            return RedirectToAction("Details", "Locales", db.Locales.Find(comment.LocaleId));
        }

        /// <summary>
        /// Izmena komentara
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca gresku ako komentar sa zadatim id-em ne postoji, u suprotnom na stranicu za izmenu komentara</returns>
        // GET: Comments/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Comment comment = db.Comments.Find(id);
            if (comment == null)
            {
                return HttpNotFound();
            }
            User user = Session["User"] as User;
            if (user == null || user.Id != comment.UserId || (user.Role != "Moderator" && user.Role != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View(comment);
        }

        /// <summary>
        /// Menja objekaat koemntara u bazi podataka
        /// </summary>
        /// <param name="comment"></param>
        /// <returns>Vraca na stranicu za izmenu komentara ako nije sve uneto, u suprotnom na detalje lokala kom komentar pripada</returns>
        // POST: Comments/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,UserId,LocaleId,TimePublished,Text")] Comment comment)
        {
            User user = Session["User"] as User;
            if (user == null || user.Id != comment.UserId || (user.Role != "Moderator" && user.Role != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            if (ModelState.IsValid)
            {
                db.Entry(comment).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Details", "Locales", db.Locales.Find(comment.LocaleId));
            }
            return View(comment);
        }

        /// <summary>
        /// Brise komentar
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca na stranicu za potvrdu o brisanju komentara. Vraca gresku ako komentar ne postoji</returns>
        // GET: Comments/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Comment comment = db.Comments.Find(id);
            if (comment == null)
            {
                return HttpNotFound();
            }
            User user = Session["User"] as User;
            if (user == null || user.Id != comment.UserId || (user.Role != "Moderator" && user.Role != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View(comment);
        }

        /// <summary>
        /// Brise objekat komentara iz baze podataka
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca na detalje lokala kome je komentar pripadao</returns>
        // POST: Comments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Comment comment = db.Comments.Find(id);
            User user = Session["User"] as User;
            if (user == null || user.Id != comment.UserId || (user.Role != "Moderator" && user.Role != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            db.Comments.Remove(comment);
            db.SaveChanges();
            return RedirectToAction("Details", "Locales", db.Locales.Find(comment.LocaleId));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
