﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

/// <summary>
/// Autori: Luka Klar 0508/15, Ivana Krstic 0362/15
/// </summary>

namespace GdeIzaci.Controllers
{
    /// <summary>
    /// EventsController - klasa za dodavanje/izmenu/brisanje/prikaz dogadjaja
    /// 
    /// @version 1.0
    /// </summary>
    public class EventsController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();
        
        /// <summary>
        /// Prikazuje sve informacije vezane za dati dogadjaj
        /// </summary>
        /// <param name="id"></param>
        /// <param name="date"></param>
        /// <returns>Vraca stranicu sa detaljima dogadjaja</returns>
        public ActionResult Details(int? id, DateTime date)
        {
            if (id == null || date == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(date, id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        /// <summary>
        /// Kreira novi dogadjaj za zadati lokal
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca pogled za kreiranje dogadjaja. Ako lokal sa zadatim id-em ne posotoji vraca gresku</returns>
        [AuthorizeModerator]
        // GET: Events/Create
        public ActionResult Create(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (db.Locales.Find(id) == null)
            {
                return HttpNotFound();
            }
            ViewBag.LocaleId = id;
            return View();
        }

        /// <summary>
        /// Dodaje novi objekat dogadjaja u bazu podataka
        /// </summary>
        /// <param name="event"></param>
        /// <returns>Vraca na detalje novokreiranog dogadjaja ili na stranicu kreiranja dogadjaja ako nisu svi podaci ispravno uneti</returns>
        [AuthorizeModerator]
        // POST: Events/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Date,LocaleId,Description,ImagePath")] Event @event)
        {
            if (ModelState.IsValid && db.Events.Find(@event.Date, @event.LocaleId) == null)
            {
                db.Events.Add(@event);
                db.SaveChanges();
                return RedirectToAction("Details", new { id = @event.LocaleId, date = @event.Date });
            }
            ViewBag.LocaleId = @event.LocaleId;
            return View(@event);
        }

        /// <summary>
        /// Menja podatke za zadati dogadjaj
        /// </summary>
        /// <param name="id"></param>
        /// <param name="date"></param>
        /// <returns>Vraca gresku ako zadati dogadjaj ne postoji, u surpotnom vraca pogled za izmenu dogadjaja</returns>
        [AuthorizeModerator]
        // GET: Events/Edit/5
        public ActionResult Edit(int? id, DateTime date)
        {
            if (id == null || date == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(date, id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        /// <summary>
        /// Menja podatke dogadjaja u bazi podataka
        /// </summary>
        /// <param name="event"></param>
        /// <returns>Vraca na detalje novoizmenjenog dogadjaja ili na stranicu izmene dogadjaja ako nisu svi podaci ispravno uneti</returns>
        [AuthorizeModerator]
        // POST: Events/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Date,LocaleId,Description,ImagePath")] Event @event)
        {
            if (ModelState.IsValid)
            {
                db.Entry(@event).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Details", new { id=@event.LocaleId, date=@event.Date });
            }
            return View(@event);
        }

        /// <summary>
        /// Brise dogadjaj
        /// </summary>
        /// <param name="id"></param>
        /// <param name="date"></param>
        /// <returns>Vraca na stranicu potvrde o brisanju dogadjaja ili gresku ako dogadjaj ne postoji</returns>
        [AuthorizeModerator]
        // GET: Events/Delete/5
        public ActionResult Delete(int? id, DateTime date)
        {
            if (id == null || date == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(date, id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        /// <summary>
        /// Brise dogadjaj iz baze podataka
        /// </summary>
        /// <param name="id"></param>
        /// <param name="date"></param>
        /// <returns>Vraca na detalje lokala kome je dogadjaj pripadao</returns>
        [AuthorizeModerator]
        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id, DateTime date)
        {
            Event @event = db.Events.Find(date, id);
            db.Events.Remove(@event);
            db.SaveChanges();
            return RedirectToAction("Details", "Locales", new { id = @event.LocaleId });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
