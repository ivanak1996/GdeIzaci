﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

/// <summary>
/// Autor: Luka Klar 0508/15
/// </summary>

namespace GdeIzaci.Controllers
{
    /// <summary>
    /// ImagesController - klasa za dodavanje/izmenu/brisanje/prikaz slika
    /// 
    /// @version 1.0
    /// </summary>
    public class ImagesController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        /// <summary>
        /// Dohvata iz baze sve slike vezane za objekat zadatog id-a
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Ako objekat sa zadatim id-em ne postoji, vraca gresku, u suprotnom vraca pogled sa svim slikama tog objekta</returns>
        public ActionResult Gallery(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Locale locale = db.Locales.Find(id);
            if (locale == null)
            {
                return HttpNotFound();
            }

            ViewBag.LocaleId = locale.Id;
            return View("Gallery", db.Images.Where(i => i.LocaleId == locale.Id).ToList());
        }

        /// <summary>
        /// Vraca pogled za gde se moze dodati slika za lokal zadatog id-a, a ako taj lokal ne postoji vraca gresku
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca pogled za dodavanje slike, ako lokal ne postoji, vraca gresku</returns>
        [AuthorizeModerator]
        // GET: Images/Create
        public ActionResult Create(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Locale locale = db.Locales.Find(id);
            if (locale == null)
            {
                return HttpNotFound();
            }
            
            return View(new Image { LocaleId = (int)id });
        }

        /// <summary>
        /// Dodaje nov objekat slike u bazu podataka
        /// </summary>
        /// <param name="image"></param>
        /// <returns>Preusmerava na galeriju slika za zadati lokal, u suprotnom vraca na stranicu dodavanja slike ako podaci nisu svi uneti</returns>
        [AuthorizeModerator]
        // POST: Images/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,LocaleId,Path")] Image image)
        {
            if (ModelState.IsValid)
            {
                db.Images.Add(image);
                db.SaveChanges();
                return RedirectToAction("Gallery", new { id = image.LocaleId });
            }
            
            return View(image);
        }

        /// <summary>
        /// Vrsi promenu slike
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca na pogled za izmenu slike. Ako slika ne postoji vraca gresku</returns>
        [AuthorizeModerator]
        // GET: Images/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Image image = db.Images.Find(id);
            if (image == null)
            {
                return HttpNotFound();
            }
            return View(image);
        }

        /// <summary>
        /// Menja link ka slici u bazi podataka
        /// </summary>
        /// <param name="image"></param>
        /// <returns>Ako je sve ispravno uneto vraca na galeriju zadatog lokala, u suprotnom vraca na pogled za izmenu slike</returns>
        [AuthorizeModerator]
        // POST: Images/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,LocaleId,Path")] Image image)
        {
            if (ModelState.IsValid)
            {
                db.Entry(image).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Gallery", new { id = image.LocaleId });
            }
            return View(image);
        }

        /// <summary>
        /// Brise sliku sa zadatim id-em
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca pogled za potvrdu brisanja, a ako slika sa zadatim id-em ne postoji vraca gresku</returns>
        [AuthorizeModerator]
        // GET: Images/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Image image = db.Images.Find(id);
            if (image == null)
            {
                return HttpNotFound();
            }
            return View(image);
        }

        /// <summary>
        /// Brise sliku iz baze podataka
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca na galeriju lokala kom je slika pripadala</returns>
        [AuthorizeModerator]
        // POST: Images/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Image image = db.Images.Find(id);
            db.Images.Remove(image);
            db.SaveChanges();
            return RedirectToAction("Gallery", new { id = image.LocaleId });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
