﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

/// <summary>
/// Autori: Luka Klar 0508/15, Ivana Krstic 0362/15
/// </summary>

namespace GdeIzaci.Controllers
{
    /// <summary>
    /// EventsController - klasa za dodavanje/izmenu/brisanje lokala
    /// 
    /// @version 1.0
    /// </summary>
    public class LocalesController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        /// <summary>
        /// Izlistava sve restorane koji su u ponudi
        /// </summary>
        /// <returns></returns>
        public ActionResult Restaurants()
        {
            ViewBag.Title = "Restorani";
            ViewBag.Image = "https://s33.postimg.cc/92miygmen/restorani.jpg";
            return View("Index", db.Locales.Where(l => l.Type == 0).ToList());
        }

        /// <summary>
        /// Izlistava sve kafice koji su u ponudi
        /// </summary>
        /// <returns></returns>
        public ActionResult Cafes()
        {
            ViewBag.Title = "Kafici";
            ViewBag.Image = "https://s33.postimg.cc/tmrcwxmq7/kafici.jpg";
            return View("Index", db.Locales.Where(l => l.Type == 1).ToList());
        }

        /// <summary>
        /// Izlistava sve klubove koji su u ponudi
        /// </summary>
        /// <returns></returns>
        public ActionResult Clubs()
        {
            ViewBag.Title = "Klubovi";
            ViewBag.Image = "https://s33.postimg.cc/r5flpoajj/klubovi.jpg";
            return View("Index", db.Locales.Where(l => l.Type == 2).ToList());
        }
        /// <summary>
        /// Izlistava sve lokale koji su u ponudi
        /// </summary>
        /// <returns></returns>
        [AuthorizeAdmin]
        // GET: Locales
        public ActionResult Index()
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            ViewBag.Title = "Svi lokali";
            ViewBag.Image = "http://dodaj.rs/images/0OJ7M.png";
            return View(db.Locales.ToList());
        }

        /// <summary>
        /// Prikazuje detalja odabranog lokala (dogadjaje, komentare...)
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca gresku ako zadati lokal ne postoji, u suprotnom vraca pogled sa detaljima</returns>
        // GET: Locales/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Locale locale = db.Locales.Find(id);
            if (locale == null)
            {
                return HttpNotFound();
            }
            return View(locale);
        }

        /// <summary>
        /// Kreira novi lokal
        /// </summary>
        /// <returns>Vraca pogled za kreiranje novog lokala</returns>
        [AuthorizeAdmin]
        // GET: Locales/Create
        public ActionResult Create()
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View();
        }

        /// <summary>
        /// Dodaje novi objekat lokala u bazu podataka
        /// </summary>
        /// <param name="locale"></param>
        /// <returns>Vraca na listu svih lokala</returns>
        [AuthorizeAdmin]
        // POST: Locales/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Address,PhoneNumber,WorkingHours,ImagePath,Type")] Locale locale)
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            if (ModelState.IsValid)
            {
                db.Locales.Add(locale);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(locale);
        }

        /// <summary>
        /// Menja zadati lokal
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca pogled za izmenu zadatog lokala. Ako lokal ne postoji vraca gresku</returns>
        [AuthorizeAdmin]
        // GET: Locales/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Locale locale = db.Locales.Find(id);
            if (locale == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View(locale);
        }

        /// <summary>
        /// Menja objekat lokala u bazi podataka
        /// </summary>
        /// <param name="locale"></param>
        /// <returns>Vraca pogled na listu lokala</returns>
        [AuthorizeAdmin]
        // POST: Locales/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Address,PhoneNumber,WorkingHours,ImagePath,Type")] Locale locale)
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            if (ModelState.IsValid)
            {
                db.Entry(locale).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(locale);
        }

        /// <summary>
        /// Brisanje lokala
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca na pogled za potvrdu brisanja lokala. Ako lokal ne postoji vraca gresku</returns>
        [AuthorizeAdmin]
        // GET: Locales/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Locale locale = db.Locales.Find(id);
            if (locale == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View(locale);
        }

        /// <summary>
        /// Brise objekat lokala iz baze podataka
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca na listu lokala</returns>
        [AuthorizeAdmin]
        // POST: Locales/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            Locale locale = db.Locales.Find(id);
            db.Locales.Remove(locale);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
