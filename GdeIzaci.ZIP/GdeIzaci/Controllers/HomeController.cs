﻿using GdeIzaci.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

/// <summary>
/// Autor: Ivana Krstic 0362/15
/// </summary>

namespace GdeIzaci.Controllers
{
    /// <summary>
    /// HomeController - klasa za prikaz pocetne stranice i kontakt informacija
    /// 
    /// @version 1.0
    /// </summary>
    public class HomeController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        /// <summary>
        /// Prikazuje na pocetnoj stranici neke dogadjaje koji su trenutno dostupni
        /// </summary>
        /// <returns>Vraca na pocetnu stranicu sajta</returns>
        public ActionResult Index()
        {
            List<Event> topEvents = db.Events.OrderByDescending(e => e.Date).ToList();
            
            int numOfEvents = topEvents.Count();
            if (numOfEvents > 0) ViewBag.FirstEvent = topEvents.ElementAt(0);
            if (numOfEvents > 1) ViewBag.SecondEvent = topEvents.ElementAt(1);
            if (numOfEvents > 2) ViewBag.ThirdEvent = topEvents.ElementAt(2);
            return View();
        }

        /// <summary>
        /// Pruza informacije o nama
        /// </summary>
        /// <returns>Vraca pogled sa kontakt informacijama</returns>
        public ActionResult Contact()
        {
            return View();
        }
    }
}