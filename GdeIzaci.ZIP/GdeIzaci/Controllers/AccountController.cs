﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

/// <summary>
/// Autori: Luka Klar 0508/15, Ivana Krstic 0362/15
/// </summary>

namespace GdeIzaci.Controllers
{
    /// <summary>
    /// AccountController - klasa za registraciju i logovanje korisnika kao i kreiranje/izlistavanje/brisanje/izmena korisnickih naloga
    /// Takodje sadrzi i logovanje i pristup admin panelu
    /// 
    /// @version 1.0
    /// </summary>
    public class AccountController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        /// <summary>
        /// Hesiranje korisnikove lozinke kako bi se zastitila njegova privatnost
        /// </summary>
        /// <param name="md5Hash"></param>
        /// <param name="input"></param>
        /// <returns>string koji predstavlja hes ulaznog stringa (korisnikove lozinke)</returns>
        private string GetMd5Hash(MD5 md5Hash, string input)
        {

            // Convert the input string to a byte array and compute the hash.
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Create a new Stringbuilder to collect the bytes
            // and create a string.
            StringBuilder sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data 
            // and format each one as a hexadecimal string.
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Return the hexadecimal string.
            return sBuilder.ToString();
        }

        /// <summary>
        /// Salje mejl sa kljucem korisniku na datu adresu, kako bi se potvrdila validnost korisnickog naloga. Taj kljuc korisnik treba da unese u pogled koji ova akcija vrati
        /// </summary>
        /// <returns>Vraca pogled gde korisnik treba da unese kljuc koji mu bude dostavljen na mejl</returns>
        [AuthorizeRegistration]
        public ActionResult ConfirmEmail()
        {
            User user = Session["TempUser"] as User;
            Session["EmailId"] = Guid.NewGuid().ToString();

            var message = new MailMessage();
            message.To.Add(new MailAddress(user.Email));
            message.From = new MailAddress("prekopcelice@mejl.com");
            message.Subject = "Registracija na Gde Izaci";
            message.Body = $"<p>Dobrodosli na Gde Izaci! Da biste zavrsili registraciju, portebno je da kljuc: {Session["EmailId"].ToString()} iskopirate u stranicu za potvrdu email adrese koja Vam se otvorila.</p>";
            message.IsBodyHtml = true;

            using (var smtp = new SmtpClient())
            {
                var credential = new NetworkCredential
                {
                    UserName = "prekopcelice@gmail.com",
                    Password = "kncerfest"
                };
                smtp.Credentials = credential;
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.Send(message);
            }

            return View();
        }

        /// <summary>
        /// Korisnik ima polje u koje treba da unese kljuc koji je dobio na mejl
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Vraca na pocetnu stranu ako je unet validan kljuc, u suprotnom ostaje na ovom pogledu</returns>
        [AuthorizeRegistration]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmEmail(EmailConfirmViewModel model)
        {
            if (model == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (model.Key == Session["EmailId"].ToString())
            {
                User user = Session["TempUser"] as User;
                db.Users.Add(user);
                db.SaveChanges();

                Session.Clear();
                Session["User"] = user;

                return RedirectToAction("Index", "Home");
            }

            return View(model);
        }

        /// <summary>
        /// Korisnik je usmeren na ovaj pogled kada zeli da se registruje
        /// </summary>
        /// <returns>Vraca pogled za registraciju korisnika</returns>
        [AuthorizeNotLoggedInUser]
        public ActionResult Register()
        {
            return View();
        }

        /// <summary>
        /// Korisnik ovde unosi trazene podatke kako bi mogao da se registruje
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Ako su svi uneti podaci uredu korisnik je usmeren na pogled gde treba da unese kljuc koji dobije na mejl, u suprotnom je vracen na ovaj pogled</returns>
        [AuthorizeNotLoggedInUser]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register([Bind(Include = "FirstName,LastName,Email,Username,Password,ConfirmPassword")] RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                User user = db.Users.Where(u => u.Username == model.Username).FirstOrDefault();

                if (user == null)
                {
                    string password = "";

                    using (MD5 md5Hash = MD5.Create())
                    {
                        password = GetMd5Hash(md5Hash, model.Password);
                    }

                    user = new User
                    {
                        Username = model.Username,
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        Password = password,
                        Email = model.Email,
                        RegistrationDate = DateTime.Now,
                        NumberOfReservations = 0,
                        IsBanned = false,
                        Role = "User"
                    };

                    Session["TempUser"] = user;

                    return RedirectToAction("ConfirmEmail");
                }
                else
                {
                    ViewBag.Message = "Vec postoji nalog sa tim korisnickim imenom.";
                    return View("Login");
                }
            }

            return View(model);
        }

        /// <summary>
        /// Korisnik je usmeren na ovaj pogled kada zeli da se prijavi
        /// </summary>
        /// <returns>Vraca pogled za prijavu</returns>
        [AuthorizeNotLoggedInUser]
        public ActionResult Login()
        {
            ViewBag.Message = "";
            return View();
        }

        /// <summary>
        /// Korisnik unosi svoje korisnicko ime i lozinku kako bi se prijavio na sajt. Korisnik ne moze da se prijavi ako je banovan
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Ako su podaci u redu preusmeren je na pocetnu stranicu, ako nisu vracen je na ovu</returns>
        [AuthorizeNotLoggedInUser]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login([Bind(Include = "Username,Password")] LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                string password = "";

                using (MD5 md5Hash = MD5.Create())
                {
                    password = GetMd5Hash(md5Hash, model.Password);
                }

                var user = db.Users.Where(u => u.Username == model.Username && u.Password == password).FirstOrDefault();

                if (user != null)
                {
                    if (user.IsBanned)
                    {
                        ViewBag.Message = $"Korisnik cije je korisnicko ime: {user.Username} je banovan sa sajta";
                    }
                    else
                    {
                        Session["User"] = user;
                        if (user.Role == "Admin")
                        {
                            Session["AdminPanelLoggedIn"] = Tuple.Create(false);
                        }
                    }

                    return RedirectToAction("Index", "Home");
                }
            }

            return View(model);
        }

        /// <summary>
        /// Korisnik se odjavljuje klikom na dugme "Logout
        /// </summary>
        /// <returns>Vracen je na pocetnu stranicu</returns>
        [AuthorizeLoggedInUser]
        [HttpGet]
        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// Ovde admini imaju pristup svim korisnickim nalozima i mogu da manipulisu njima
        /// </summary>
        /// <returns>Ako je admin ulogovan prikazuje mu se lista korisnika, u suprotnom je preusmeren na pogled za prijavu admina</returns>
        [AuthorizeAdmin]
        // GET: Account
        public ActionResult Index()
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View(db.Users.ToList());
        }

        /// <summary>
        /// Pogled gde admin unosi podatke (korisnicko ime i lozinku) kako bi mogao da pristupi admin panelu
        /// </summary>
        /// <returns>Vraca pogled za prijavu admina ako admin nije ulogovan, u suprotnom ga preusmerava na admin panel</returns>
        [AuthorizeAdmin]
        public ActionResult AdminLogin()
        {
            if ((Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminPanel", "Account");
            }
            ViewBag.Message = "";
            return View();
        }

        /// <summary>
        /// Vrsi validaciju admina na osnovu unetih podataka
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Ako su uneti podaci u redu preusmeren je na admin panel, u suprotnom mora ponovo uneti podatke</returns>
        [AuthorizeAdmin]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AdminLogin([Bind(Include = "Username,Password")] AdminLoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                string password = "";

                using (MD5 md5Hash = MD5.Create())
                {
                    password = GetMd5Hash(md5Hash, model.Password);
                }

                var user = Session["User"] as User;

                if (user.Username == model.Username && user.Password == password)
                {
                    Session["AdminPanelLoggedIn"] = Tuple.Create(true);
                    return RedirectToAction("AdminPanel");
                }
                else
                {
                    ViewBag.Message = "Korisnicko ime ili lozinka nisu dobro uneti";
                }
            }

            return View(model);
        }

        /// <summary>
        /// Admin ima pristup lokalima i korisnicima i moze manipulisati njima
        /// </summary>
        /// <returns>Ako je admin prijavljen prosledjen je na admin panel, u suprotnom je preusmeren na stranicu za prijavu admina</returns>
        [AuthorizeAdmin]
        public ActionResult AdminPanel()
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View();
        }

        /// <summary>
        /// Ako korisnik postoji, admin je pitan da li zeli da potvrdi ban
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca gresku ako je unet los id, vraca na admin login ako admin nije prijavljen, u suprotnom vraca odgovarajuci pogled</returns>
        [AuthorizeAdmin]
        // GET: Account/Ban/5
        public ActionResult Ban(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View(user);
        }

        /// <summary>
        /// Ako je admin prijavljen korisnik sa zadatim id-em ce biti banovan
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca na pocetnu ako je ban uspesan i admin prijavljen, u suprotnom na stranicu za admin login</returns>
        [AuthorizeAdmin]
        // POST: Account/Ban/5
        [HttpPost, ActionName("Ban")]
        [ValidateAntiForgeryToken]
        public ActionResult BanConfirmed(int? id)
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            User user = db.Users.Find(id);
            user.IsBanned = true;
            db.Entry(user).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Skida ban sa korisnickog naloga
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Ako je admin ulogovan ban je skinut i admin preusmeren na listu naloga. U suprotnom na stranicu za admin login</returns>
        [AuthorizeAdmin]
        public ActionResult Unban(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            user.IsBanned = false;
            db.Entry(user).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Unapredjuje korisnika u moderatora
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca gresku ako korisnik ne postoji, vraca na admin login ako admin nije prijavljen. Ako je sve uspesno vraca na listu svih naloga</returns>
        [AuthorizeAdmin]
        public ActionResult Promote(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }

            user.Role = "Moderator";
            db.Entry(user).State = EntityState.Modified;
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Skida moderatorska prava korisniku
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca gresku ako korisnik ne postoji, vraca na admin login ako admin nije prijavljen. Ako je sve uspesno vraca na listu svih naloga</returns>
        [AuthorizeAdmin]
        public ActionResult Demote(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }

            if (user.NumberOfReservations < 100)
            {
                user.Role = "User";
            }
            else
            {
                user.Role = "VIP";
            }
            db.Entry(user).State = EntityState.Modified;
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Izmena licnih podataka
        /// </summary>
        /// <returns>Vraca pogled na stranicu za izmenu licnih podataka</returns>
        public ActionResult Edit()
        {
            ViewBag.Message = "";
            return View();
        }

        /// <summary>
        /// Provere da li su uneti podaci validni, pre svega lozinka, a zatim i da li je korisnicko ime zauzeto. Ako je sve u redu, licni podaci su izmenjeni
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Ako je lozinka nevalidna, ili neki podatak nije unet ili je korisnicko ime zauzeto, vracen je na pogled za izmenu podataka, u suprotnom je vracen na pocetnu</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(EditViewModel model)
        {
            if (ModelState.IsValid)
            {
                User sessionUser = Session["User"] as User;
                User user = db.Users.Find(sessionUser.Id);

                using (MD5 md5Hash = MD5.Create())
                {
                    if (user.Password == GetMd5Hash(md5Hash, model.Password))
                    {
                        if (model.Username != user.Username && db.Users.Where(u => u.Username == model.Username).FirstOrDefault() != null)
                        {
                            ViewBag.Message = "Korisnicko ime je vec zauzeto.";
                            return View(model);
                        }

                        sessionUser.Username = user.Username = model.Username;
                        sessionUser.FirstName = user.FirstName = model.FirstName;
                        sessionUser.LastName = user.LastName = model.LastName;
                        sessionUser.Email = user.Email = model.Email;
                        sessionUser.Password = user.Password = GetMd5Hash(md5Hash, model.NewPassword);

                        db.Entry(user).State = EntityState.Modified;
                        db.SaveChanges();

                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ViewBag.Message = "Nije uneta dobra lozinka.";
                    }
                }
            }

            return View(model);
        }

        /// <summary>
        /// Provera da li ej admin prijavljen i da li postoji korisnik sa zadatim id-em
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca pogled gde je admin pitan da li zeli da obrise korisnicki nalog. Ako nije prijavljen biva vracen na admin login</returns>
        [AuthorizeAdmin]
        // GET: Account/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View(user);
        }

        /// <summary>
        /// Brise korisnicki nalog iz baze podataka
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Vraca pogled na listu korisnika ili na admin login ako admin nije prijavljen</returns>
        [AuthorizeAdmin]
        // POST: Account/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            User user = db.Users.Find(id);
            foreach (Reservation r in user.Reservations)
            {
                ++r.Offer.Count;
            }
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
