﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

namespace GdeIzaci.Controllers
{
    public class LocalesController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        public ActionResult Restaurants()
        {
            ViewBag.Title = "Restorani";
            ViewBag.Image = "https://s33.postimg.cc/92miygmen/restorani.jpg";
            return View("Index", db.Locales.Where(l => l.Type == 0).ToList());
        }

        public ActionResult Cafes()
        {
            ViewBag.Title = "Kafici";
            ViewBag.Image = "https://s33.postimg.cc/tmrcwxmq7/kafici.jpg";
            return View("Index", db.Locales.Where(l => l.Type == 1).ToList());
        }

        public ActionResult Clubs()
        {
            ViewBag.Title = "Klubovi";
            ViewBag.Image = "https://s33.postimg.cc/r5flpoajj/klubovi.jpg";
            return View("Index", db.Locales.Where(l => l.Type == 2).ToList());
        }

        [AuthorizeAdmin]
        // GET: Locales
        public ActionResult Index()
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            ViewBag.Title = "Svi lokali";
            ViewBag.Image = "http://dodaj.rs/images/0OJ7M.png";
            return View(db.Locales.ToList());
        }

        // GET: Locales/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Locale locale = db.Locales.Find(id);
            if (locale == null)
            {
                return HttpNotFound();
            }
            return View(locale);
        }

        [AuthorizeAdmin]
        // GET: Locales/Create
        public ActionResult Create()
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View();
        }

        [AuthorizeAdmin]
        // POST: Locales/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Address,PhoneNumber,WorkingHours,ImagePath,Type")] Locale locale)
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            if (ModelState.IsValid)
            {
                db.Locales.Add(locale);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(locale);
        }

        [AuthorizeAdmin]
        // GET: Locales/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Locale locale = db.Locales.Find(id);
            if (locale == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View(locale);
        }

        [AuthorizeAdmin]
        // POST: Locales/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Address,PhoneNumber,WorkingHours,ImagePath,Type")] Locale locale)
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            if (ModelState.IsValid)
            {
                db.Entry(locale).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(locale);
        }

        [AuthorizeAdmin]
        // GET: Locales/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Locale locale = db.Locales.Find(id);
            if (locale == null)
            {
                return HttpNotFound();
            }
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            return View(locale);
        }

        [AuthorizeAdmin]
        // POST: Locales/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (!(Session["AdminPanelLoggedIn"] as Tuple<bool>).Item1)
            {
                return RedirectToAction("AdminLogin", "Account");
            }
            Locale locale = db.Locales.Find(id);
            db.Locales.Remove(locale);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
