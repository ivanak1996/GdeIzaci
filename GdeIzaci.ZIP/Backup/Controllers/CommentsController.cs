﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

namespace GdeIzaci.Controllers
{
    public class CommentsController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        // POST: Comments/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [AuthorizeLoggedInUser]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,UserId,LocaleId,TimePublished,Text")] Comment comment)
        {
            if (ModelState.IsValid)
            {
                db.Comments.Add(comment);
                db.SaveChanges();
            }
            return RedirectToAction("Details", "Locales", db.Locales.Find(comment.LocaleId));
        }

        // GET: Comments/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Comment comment = db.Comments.Find(id);
            if (comment == null)
            {
                return HttpNotFound();
            }
            User user = Session["User"] as User;
            if (user == null || user.Id != comment.UserId || (user.Role != "Moderator" && user.Role != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View(comment);
        }

        // POST: Comments/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,UserId,LocaleId,TimePublished,Text")] Comment comment)
        {
            User user = Session["User"] as User;
            if (user == null || user.Id != comment.UserId || (user.Role != "Moderator" && user.Role != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            if (ModelState.IsValid)
            {
                db.Entry(comment).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Details", "Locales", db.Locales.Find(comment.LocaleId));
            }
            return View(comment);
        }

        // GET: Comments/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Comment comment = db.Comments.Find(id);
            if (comment == null)
            {
                return HttpNotFound();
            }
            User user = Session["User"] as User;
            if (user == null || user.Id != comment.UserId || (user.Role != "Moderator" && user.Role != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            return View(comment);
        }

        // POST: Comments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Comment comment = db.Comments.Find(id);
            User user = Session["User"] as User;
            if (user == null || user.Id != comment.UserId || (user.Role != "Moderator" && user.Role != "Admin"))
            {
                return RedirectToAction("Index", "Home");
            }
            db.Comments.Remove(comment);
            db.SaveChanges();
            return RedirectToAction("Details", "Locales", db.Locales.Find(comment.LocaleId));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
