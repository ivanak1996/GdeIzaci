﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

namespace GdeIzaci.Controllers
{
    public class EventsController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();
        
        public ActionResult Details(int? id, DateTime date)
        {
            if (id == null || date == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(date, id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        [AuthorizeModerator]
        // GET: Events/Create
        public ActionResult Create(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (db.Locales.Find(id) == null)
            {
                return HttpNotFound();
            }
            ViewBag.LocaleId = id;
            return View();
        }

        [AuthorizeModerator]
        // POST: Events/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Date,LocaleId,Description,ImagePath")] Event @event)
        {
            if (ModelState.IsValid && db.Events.Find(@event.Date, @event.LocaleId) == null)
            {
                db.Events.Add(@event);
                db.SaveChanges();
                return RedirectToAction("Details", new { id = @event.LocaleId, date = @event.Date });
            }
            ViewBag.LocaleId = @event.LocaleId;
            return View(@event);
        }

        [AuthorizeModerator]
        // GET: Events/Edit/5
        public ActionResult Edit(int? id, DateTime date)
        {
            if (id == null || date == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(date, id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        [AuthorizeModerator]
        // POST: Events/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Date,LocaleId,Description,ImagePath")] Event @event)
        {
            if (ModelState.IsValid)
            {
                db.Entry(@event).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Details", new { id=@event.LocaleId, date=@event.Date });
            }
            return View(@event);
        }

        [AuthorizeModerator]
        // GET: Events/Delete/5
        public ActionResult Delete(int? id, DateTime date)
        {
            if (id == null || date == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Event @event = db.Events.Find(date, id);
            if (@event == null)
            {
                return HttpNotFound();
            }
            return View(@event);
        }

        [AuthorizeModerator]
        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id, DateTime date)
        {
            Event @event = db.Events.Find(date, id);
            db.Events.Remove(@event);
            db.SaveChanges();
            return RedirectToAction("Details", "Locales", new { id = @event.LocaleId });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
