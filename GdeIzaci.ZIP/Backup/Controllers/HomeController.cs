﻿using GdeIzaci.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GdeIzaci.Controllers
{
    public class HomeController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        public ActionResult Index()
        {
            List<Event> topEvents = db.Events.OrderByDescending(e => e.Date).ToList();
            
            int numOfEvents = topEvents.Count();
            if (numOfEvents > 0) ViewBag.FirstEvent = topEvents.ElementAt(0);
            if (numOfEvents > 1) ViewBag.SecondEvent = topEvents.ElementAt(1);
            if (numOfEvents > 2) ViewBag.ThirdEvent = topEvents.ElementAt(2);
            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }
    }
}