﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using GdeIzaci.ActionFilters;
using GdeIzaci.Models;

namespace GdeIzaci.Controllers
{
    public class OffersController : Controller
    {
        private GdeIzaciDb db = new GdeIzaciDb();

        [AuthorizeModerator]
        // GET: Offers/Create
        public ActionResult Create(int? id, DateTime date)
        {
            if (id == null || date == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if (db.Events.Find(date, id) == null)
            {
                return HttpNotFound();
            }
            ViewBag.LocaleId = id;
            ViewBag.EventDate = date;
            return View();
        }

        [AuthorizeModerator]
        // POST: Offers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,EventDate,LocaleId,Description,Count")] Offer offer)
        {
            if (ModelState.IsValid)
            {
                db.Offers.Add(offer);
                db.SaveChanges();
                return RedirectToAction("Details", "Events", new { id = offer.LocaleId, date = offer.EventDate });
            }
            ViewBag.LocaleId = offer.LocaleId;
            ViewBag.EventDate = offer.EventDate;
            return View(offer);
        }
        
        [AuthorizeLoggedInUser]
        public ActionResult Reserve(int? id)
        {
            User user = Session["User"] as User;
            if (id == null || user == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Offer offer = db.Offers.Find(id);
            if (offer == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            Reservation reservation = new Reservation
            {
                Id = Guid.NewGuid(),
                UserId = user.Id,
                OfferId = (int)id
            };

            db.Reservations.Add(reservation);
            --offer.Count;

            User query = db.Users.Find(user.Id);
            query.NumberOfReservations = ++user.NumberOfReservations;
            if (user.NumberOfReservations >= 100 && user.Role == "User")
                query.Role = user.Role = "VIP";

            db.SaveChanges();

            var message = new MailMessage();
            message.To.Add(new MailAddress(user.Email));
            message.From = new MailAddress("prekopcelice@mejl.com");
            message.Subject = "Rezervacija";
            message.Body = $"<p>Uspesno ste izvrsili rezervaciju. Vas rezervacioni kod je: {reservation.Id}" + (user.NumberOfReservations < 100 ? "" : "VIP") + " i njega cete pokazati osoblju kada stignete na lokaciju.</p>";
            message.IsBodyHtml = true;

            using (var smtp = new SmtpClient())
            {
                var credential = new NetworkCredential
                {
                    UserName = "prekopcelice@gmail.com",
                    Password = "kncerfest"
                };
                smtp.Credentials = credential;
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.EnableSsl = true;
                smtp.Send(message);
            }

            return RedirectToAction("Details", "Events", new { id = offer.LocaleId, date = offer.EventDate });
        }

        [AuthorizeLoggedInUser]
        public ActionResult Cancel(int? id)
        {
            User user = Session["User"] as User;
            if (id == null || user == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Reservation reservation = db.Reservations.Where(r => r.OfferId == (int)id && r.UserId == user.Id).FirstOrDefault();
            if (reservation == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            int localeId = reservation.Offer.LocaleId;
            DateTime eventDate = reservation.Offer.EventDate;

            ++reservation.Offer.Count;
            db.Reservations.Remove(reservation);

            User query = db.Users.Find(user.Id);
            query.NumberOfReservations = --user.NumberOfReservations;
            if (user.NumberOfReservations < 100 && user.Role == "VIP")
                query.Role = user.Role = "User";

            db.SaveChanges();

            return RedirectToAction("Details", "Events", new { id = localeId, date = eventDate });
        }

        [AuthorizeModerator]
        // GET: Offers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Offer offer = db.Offers.Find(id);
            if (offer == null)
            {
                return HttpNotFound();
            }
            return View(offer);
        }

        [AuthorizeModerator]
        // POST: Offers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,EventDate,LocaleId,Description,UserId,ReservationCode")] Offer offer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(offer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Details", "Events", new { id = offer.LocaleId, date = offer.EventDate });
            }
            return View(offer);
        }

        [AuthorizeModerator]
        // GET: Offers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Offer offer = db.Offers.Find(id);
            if (offer == null)
            {
                return HttpNotFound();
            }
            return View(offer);
        }

        [AuthorizeModerator]
        // POST: Offers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Offer offer = db.Offers.Find(id);
            db.Offers.Remove(offer);
            db.SaveChanges();
            return RedirectToAction("Details", "Events", new { id = offer.LocaleId, date = offer.EventDate });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
