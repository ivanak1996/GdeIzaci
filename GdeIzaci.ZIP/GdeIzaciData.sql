﻿USE [GdeIzaci]
GO

--Clubs
INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('PORT','Ušce, Beograd 11000','+38163 1111211','23:30 - 04:00','http://www.u-beogradu.com/uploads/2015/08/splav-port-13-823x420.jpg',2)

INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('Hype Belgrade Night Club','Karadordeva 46, Beograd 11000','+38165 4495555','00:00 - 05:00','https://www.kudaveceras.rs/images/offers/1507741127-klub-hype-2.jpg',2)

INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('Hot Mess','Ušce bb, Beograd 11000','+38166 222152','08:00 - 05:00','https://www.kudaveceras.rs/images/offers/1435655061-Hotmess_1.jpg',2)

--Restaurants
INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('Dva Jelena','Skadarska, Beograd','+38111 7234885','10:00 - 01:00','http://www.dvajelena.rs/files/images/2015/8/14/IMG_2940.jpg',0)

INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('Mali Vrabac','Skadarska, Beograd','+38169 1872252','10:00 - 01:00','https://media-cdn.tripadvisor.com/media/photo-s/04/31/eb/c8/mali-vrabac.jpg',0)

INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('Frans','Bulevar oslobodenja 18a, Beograd 11000','+38111 2641944','10:00 - 00:00','http://www.frans.rs/wp-content/uploads/2015/05/restoran-3.jpg',0)

--Cafes
INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('Boutique','Trg republike 3, Beograd','+38111 2621373','08:00 - 01:00','https://www.beogradnocu.com/wp-content/uploads/2013/09/DSC_00212.jpg',1)

INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('Cross','Mileševska 73, Beograd 11000','+38164 9040904','08:00 - 00:00','https://www.beogradnocu.com/wp-content/uploads/2016/05/Bar-Cross-enterijer3.jpg',1)

INSERT INTO [dbo].[Locale]([Name],[Address],[PhoneNumber],[WorkingHours],[ImagePath],[Type]) 
VALUES('Industrija bar','Karadordeva 23, Beograd 11000','+38164 1195519','09:00 - 04:00','https://www.beogradnocu.com/wp-content/uploads/2014/04/DSC_0054-17.jpg',1)

--PORT
INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/12/2018', 1, 
		'Grupa Lexington pocela je sa radom 2004. godine u Beogradu. Simbolika reci Lexington, uvek je bila olicenje glamura, elegancije i ozbiljnosti što i 
		jeste imidž ove grupe.Lexington se vec izdvojila kao jedan od najperspektivnijih sastava u Srbiji a saradjivali su i sa najeminentnijim autorima i 
		muzicarima iz regiona. Momci iz Beograda imaju velike ambicije a za uspeh ce nastaviti da se bore dobrom pesmom i kvalitetnim pop zvukom.',
		'http://www.mojnovisad.com/files/_thumb/600x400/event/6/7/4/21674/21674-19437794-1624684284208756-7628667299932197880-n.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/13/2018', 1, 
		'Bend “EXTRA ORCHESTRA” osnovan je 2004. godine, i od tada je nastupao u svim znacajnijim beogradskim klubovima koji neguju “živu svirku” pop-rok 
		orijentacije.Strpljivim radom postali su jedan od najtraženijih klupskih bendova, a njihova misija je posvecena vracanju dobrog zvuka u prestižne 
		gradske lokale, ali i predstavljanje pop-rok muzike na mestima gde takvih svirki ranije nije bilo.Podjednako dobro vladaju svim muzickim stilovima – 
		od izvornih, preko pop-rock pa sve do jazz i elektronskih.',
		'http://www.azzaroclub.rs/CMS/partneri/extra_orchestra.jpg')


--HYPE
INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/11/2018', 2, 
		'Franki Rizardo - DJ i producent. Mladi umetnik nastavlja da se dokazuje kao jedan od najboljih Holandanina u Dabce muzici, demonstrirajuc´i 
		solidnu produkcijsku karijeru sa izdanjima koja obuhvataju saradnju sa vrhunskim izdavackim kucama, ukljucujuc´i i Defected Records. Dodite i 
		uverite se zašto je upravo ovaj DJ jedan od natraženijih.',
		'https://sankeysibiza.info/wp-content/uploads/frank-yr.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/12/2018', 2, 
		'Chelina Manuhutu rodena u Amsterdamu, je DJ i producent. Bez sumnje jedan od najuzbudljivijih muzickih zvezda koje Amsterdam nudi ovih dana. 
		Holandanka Chelina Manuhutu preuzima podzemnu muzicku scenu kroz njen specifican stil visokokvalitetnih mikseva.',
		'http://chelina-manuhutu.com/wp-content/uploads/2014/04/22791932_1664811456904029_2065885561256128961_o.jpg')

--Hot Mess
INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/12/2018', 3, 
		'Miroslav Miletic´ alias SMTNG vec´ deset godina pokazuje svoje veštine i talente u polju elektronske muzike na sceni Srbije. Poceo je svoju uspešnu 
		DJ karijeru u gradu Požarevcu, svom rodnom mestu, da bi po preseljenju u Novi Sad u 19-oj godini poceo da radi u u to vreme omiljenom noc´nom klubu - 
		"Ritmo Latino", gde pocinje njegova ozbiljnija karijera.',
		'https://www.residentadvisor.net/images/profiles/smtng.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/13/2018', 3, 
		'Rodena u Italiji i podignuta od strane nekonvencionalne, slobodne porodice, Elena Colombi se preselila u London 2008. godine i postavila uspešnu 
		seriju žurki koje su njeno ime utvrdile na podzemnoj sceni. Sada je ugledni DJ i radio domac´in na NTS-u. Za nju, poznavanje i osec´anje muzike ne 
		znace specijalizaciju u jednom odredenom žanru.',
		'https://pbs.twimg.com/profile_images/770350313903710213/CIMBffjh_400x400.jpg')

--Dva Jelena
INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/11/2018', 4, 
		'Restoran „Dva jelena“, jedan od najstarijih i najposećenijih u Beogradu, više od 100 godina najveći je à la carte restoran na prostoru nekadašnje Jugoslavije. 
		Nalazi se u Skadarliji, boemskom srcu grada poznatom i kao beogradski Monmartr.',
		'https://www.gdeizaci.com/upload/Place/Logo/2015-06/restoran_dva_jelena_skadarlija.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/12/2018', 4, 
		'Restoran „Dva jelena“, jedan od najstarijih i najposećenijih u Beogradu, više od 100 godina najveći je à la carte restoran na prostoru nekadašnje Jugoslavije. 
		Nalazi se u Skadarliji, boemskom srcu grada poznatom i kao beogradski Monmartr.',
		'https://www.gdeizaci.com/upload/Place/Logo/2015-06/restoran_dva_jelena_skadarlija.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/13/2018', 4, 
		'Restoran „Dva jelena“, jedan od najstarijih i najposećenijih u Beogradu, više od 100 godina najveći je à la carte restoran na prostoru nekadašnje Jugoslavije. 
		Nalazi se u Skadarliji, boemskom srcu grada poznatom i kao beogradski Monmartr.',
		'https://www.gdeizaci.com/upload/Place/Logo/2015-06/restoran_dva_jelena_skadarlija.jpg')

--Mali Vrabac

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/11/2018', 5, 
		'Zamislite mesto gde idete kada ste željni da pojedete nešto vrhunskog ukusa pripremljeno od globalno-nagradivanog kuvara, doživite uslugu kao iz 
		najboljih svetskih resorana, gde možete da uživate u najboljim tamburašima i degustirate najbolja domaca i strana vina sa geografskim poreklom. 
		Takvo mesto je idealno kako za boeme, tako i za porodicne, ali i poslovne ljude. Restoran Mali Vrabac nudi sve to u jednom.',
		'https://www.malivrabac.rs/images/yootheme/image/SlideShow/home/konacno/1.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/12/2018', 5, 
		'Zamislite mesto gde idete kada ste željni da pojedete nešto vrhunskog ukusa pripremljeno od globalno-nagradivanog kuvara, doživite uslugu kao iz 
		najboljih svetskih resorana, gde možete da uživate u najboljim tamburašima i degustirate najbolja domaca i strana vina sa geografskim poreklom. 
		Takvo mesto je idealno kako za boeme, tako i za porodicne, ali i poslovne ljude. Restoran Mali Vrabac nudi sve to u jednom.',
		'https://www.malivrabac.rs/images/yootheme/image/SlideShow/home/konacno/1.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/13/2018', 5, 
		'Zamislite mesto gde idete kada ste željni da pojedete nešto vrhunskog ukusa pripremljeno od globalno-nagradivanog kuvara, doživite uslugu kao iz 
		najboljih svetskih resorana, gde možete da uživate u najboljim tamburašima i degustirate najbolja domaca i strana vina sa geografskim poreklom. 
		Takvo mesto je idealno kako za boeme, tako i za porodicne, ali i poslovne ljude. Restoran Mali Vrabac nudi sve to u jednom.',
		'https://www.malivrabac.rs/images/yootheme/image/SlideShow/home/konacno/1.jpg')

--Frans
INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/11/2018', 6, 
		'Naša istaknuta džez vokalna solistkinja Jelena Jovovic je završila Džez akademiju u Gracu kao dak generacije i stipendista Erasmus programa za posebno nadarene umetnike.Tokom svoje bogate umetnicke karijere saradivala je sa mnogim istaknutim džez muzicarima iz Evrope, Afrike i Amerike, medu kojima su Fric Pauer, Oliver Kent, Bob Muver, Mark Marfi, Johanes Enders, Stiv Vilijams, Šila Džordan, Endi Bej, Big bend RTS-a, Stjepko Gut, Duško Gojkovic, Bojan Zulfikarpašic, Vasil Hadžimanov.
		Ove nedelje nastupice sa svojim kvartetom.',
		'https://scontent.fbeg4-1.fna.fbcdn.net/v/t1.0-9/14322437_10204991381982964_4504290142838421389_n.jpg?_nc_cat=0&_nc_eui2=AeHDVUGYJ996p4Dv2tA0e2wIYmZrEFByFXdiqUDNOB7_sATa-C0sNyG0LgNDF0noI2-WLEz-pV--yf2KYGi_5zSclp_eMnESMaPa39JGSRlrVA&oh=5df368ec835b2eb6e4144e641f4b6807&oe=5B7618FB')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/13/2018', 6, 
		'Odmah nakon Festivala fantasticne književnosti Art-Anima u bašti našeg restorana nastupice FlitaraGauta, džez duo koji cine Jovana (vokal, flauta) i 
		Igor Lazic (gitara). Na beogradskoj džez sceni aktivni su od 2009. godine. a bave se izvodenjem kako originalnih džez kompozicija, tako i kompozicija 
		drugih pravaca prearanžiranih u istom maniru. ',
		'https://scontent.fbeg4-1.fna.fbcdn.net/v/t1.0-9/33676138_1561125367343500_884804872619163648_n.jpg?_nc_cat=0&_nc_eui2=AeETOd90JxO_ig_-0V84h4in6rDqgx8ORWx-dxm_UzkTNPKBo7rER6Z8UmILlPNcGOzWb_x-KxppO-0CLgEyrCtaHD1wm3HCZDylpnhHqvmLOg&oh=82276a803e65dfc71fd83f3f072e34dc&oe=5BB33C8A')

--Cross
INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/11/2018', 8, 
		'Zaboravite na sve svoje obaveze i svratite veceras od 20h u Cross jer vas ocekuje Live n Acoustic i fantasticna akusticna svirka! Izaberite najlepši 
		kutak ovog sjajnog kafica, porucite svoje omiljeno pice i prepustite se vrhunskom hedonizmu. Vidimo se!',
		'http://www.svetplus.com/images/vesti/a/171406924.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/13/2018', 8, 
		'Zaboravite na sve svoje obaveze i svratite veceras od 20h u Cross jer vas ocekuje Rock n Roll vece uz Aura Bends! Izaberite najlepši kutak ovog sjajnog kafica, 
		porucite svoje omiljeno pice i prepustite se vrhunskom hedonizmu. Vidimo se!',
		'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMyJ_3IynskWC3XJdsSzBe6lcVyblnct2_iUVR6ktNc45BWDumNA')

--Industrija
INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/11/2018', 9, 
		'Zoran Kesic Kesa - vokal i klavijatura 
		Zoran Gajic Gaja - gitara
		Sanja Vasiljevic - vokal
		Nakon višegodišnje saradnje, dokazano je da je upravo ovaj neobicni, a opet idealno uskladeni spoj mladosti i iskustva dobitna kombinacija i 
		sinonim za kvalitetnu svirku i zagarantovani provod.',
		'http://grupaplaybox.com/wp-content/uploads/2017/05/playbox1.jpg')

INSERT INTO [dbo].[Event]([Date],[LocaleId],[Description],[ImagePath])
VALUES('07/13/2018', 9, 
		'Ideja je da interpretacijom akusticno izvrnutih melodija, nošenih strastvenim ritmovima muzike sa razlicitih geografskih podneblja predstavimo
		 auditorijumu elemente popularne kulture na najbliži moguci nacin! Specijalnost su jedinstveni aranžmani popularnih internacionalnih i ex-YU pesama, 
		 ali najbolje je sve to doživeti putem auditivnih draži...',
		'https://cdn-az.allevents.in/banners/0d6cfd1c35bfdfd32a27bc551ae6af09')

--PORT
INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 1, 'Barski sto kapaciteta 4-6 osoba i nalazi se u centralnom delu kluba. Bez uslova', 20)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 1, 'Sank - 1 rezervacija šanka važi za jednu osobu, bez uslova', 25)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 1, 'Separe za 6 osoba - Obavezne dve flaše premium pica', 6)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 1, 'Separe za 10 osoba - Obavezne tri flaše premium pica', 2)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 1, 'Barski sto kapaciteta 4-6 osoba i nalazi se u centralnom delu kluba. Bez uslova', 20)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 1, 'Sank - 1 rezervacija šanka važi za jednu osobu, bez uslova', 25)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 1, 'Separe za 6 osoba - Obavezne dve flaše premium pica', 6)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 1, 'Separe za 10 osoba - Obavezne tri flaše premium pica', 2)

--Hype
INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 2, 'Barski sto kapaciteta 4-6 osoba i nalazi se u centralnom delu kluba. Bez uslova', 18)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 2, 'Sank - 1 rezervacija šanka važi za jednu osobu, bez uslova', 25)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 2, 'Separe za 6 osoba - Obavezne dve flaše premium pica', 8)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 2, 'Separe za 10 osoba - Obavezne tri flaše premium pica', 4)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 2, 'Barski sto kapaciteta 4-6 osoba i nalazi se u centralnom delu kluba. Bez uslova', 18)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 2, 'Sank - 1 rezervacija šanka važi za jednu osobu, bez uslova', 25)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 2, 'Separe za 6 osoba - Obavezne dve flaše premium pica', 8)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 2, 'Separe za 10 osoba - Obavezne tri flaše premium pica', 4)

--Hot Mess

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 3, 'Sank - 1 rezervacija šanka važi za jednu osobu, bez uslova', 30)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 3, 'Separe za 4 osobe - Obavezna jedna flaša premium pica',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 3, 'Rezervacija za jednu osobu - Rezervišite i nadite svoje mesto pored bazena ili kod dj-a ili možda na lazy bag-u',100)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 3, 'Sank - 1 rezervacija šanka važi za jednu osobu, bez uslova', 30)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 3, 'Separe za 4 osobe - Obavezna jedna flaša premium pica',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 3, 'Rezervacija za jednu osobu - Rezervišite i nadite svoje mesto pored bazena ili kod dj-a ili možda na lazy bag-u',100)

--Dva Jelena

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 4, 'Sto za 4 osobe u zatvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 4, 'Sto za 6 osoba u zatvorenom delu restorana. Vecera obavezna',12)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 4, 'Sto za 3 osobe u otvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 4, 'Sto za 4 osobe u zatvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 4, 'Sto za 6 osoba u zatvorenom delu restorana. Vecera obavezna',12)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 4, 'Sto za 3 osobe u otvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 4, 'Sto za 4 osobe u zatvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 4, 'Sto za 6 osoba u zatvorenom delu restorana. Vecera obavezna',12)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 4, 'Sto za 3 osobe u otvorenom delu restorana. Vecera obavezna',10)

--Mali Vrabac

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 5, 'Sto za 4 osobe u zatvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 5, 'Sto za 6 osoba u zatvorenom delu restorana. Vecera obavezna',12)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 5, 'Sto za 3 osobe u otvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 5, 'Sto za 4 osobe u zatvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 5, 'Sto za 6 osoba u zatvorenom delu restorana. Vecera obavezna',12)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/12/2018', 5, 'Sto za 3 osobe u otvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 5, 'Sto za 4 osobe u zatvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 5, 'Sto za 6 osoba u zatvorenom delu restorana. Vecera obavezna',12)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 5, 'Sto za 3 osobe u otvorenom delu restorana. Vecera obavezna',10)

--Frans

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 6, 'Sto za 4 osobe u zatvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 6, 'Sto za 6 osoba u zatvorenom delu restorana. Vecera obavezna',12)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 6, 'Sto za 3 osobe u otvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 6, 'Sto za 4 osobe u zatvorenom delu restorana. Vecera obavezna',10)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 6, 'Sto za 6 osoba u zatvorenom delu restorana. Vecera obavezna',12)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 6, 'Sto za 3 osobe u otvorenom delu restorana. Vecera obavezna',10)

--Cross
INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 8, 'Sto za 4 osobe u zatvorenom delu kafica.',6)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 8, 'Sank - budite blizu vašeg omiljenog koktela.',20)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 8, 'Stolovi za 2 osobe u otvorenom delu kafica.',8)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 8, 'Stolovi za 3 osobe u basti kafica.',9)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 8, 'Sto za 4 osobe u zatvorenom delu kafica.',6)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 8, 'Sank - budite blizu vašeg omiljenog koktela.',20)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 8, 'Stolovi za 2 osobe u otvorenom delu kafica.',8)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 8, 'Stolovi za 3 osobe u basti kafica.',9)

--Industrija

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 9, 'Sto za 4 osobe u zatvorenom delu kafica.',6)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 9, 'Sank - budite blizu vašeg omiljenog koktela.',30)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 9, 'Stolovi za 2 osobe u otvorenom delu kafica.',5)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/11/2018', 9, 'Stolovi za 3 osobe u basti kafica.',6)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 9, 'Sto za 4 osobe u zatvorenom delu kafica.',6)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 9, 'Sank - budite blizu vašeg omiljenog koktela.',30)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 9, 'Stolovi za 2 osobe u otvorenom delu kafica.',5)

INSERT INTO [dbo].[Offer]([EventDate],[LocaleId],[Description],[Count])
VALUES('07/13/2018', 9, 'Stolovi za 3 osobe u basti kafica.',6)


--Slike
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(1,'https://www.gdeizaci.com/upload/Place/InteriorGalleries/2015-06/splav_port_55.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(1,'https://www.gdeizaci.com/upload/Place/InteriorGalleries/2015-06/splav_port_1.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(1,'https://www.kudaveceras.rs/images/offers/1466432779-splav-port-kasina-beorad_(1).jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(1,'http://beogradnocu.telegraf.rs/wp-content/uploads/gallery/1308414/10869307_658713837599247_7379958051410296174_o.jpg')

INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(2,'https://www.gdeizaci.com/upload/Place/InteriorGalleries/2017-11/klub_hype_3.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(2,'https://poshbelgrade.com/wp-content/uploads/2018/03/belgrade_clubs_zurka_nightlife_izlazak_party_in_belgrade_best_clubs_party_clubbing_provod_hype_17.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(2,'https://www.gdeizaci.com/upload/Place/InteriorGalleries/2017-11/klub_hype_1.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(2,'https://reserve.rs/wp-content/uploads/2017/10/klub_hype_1.jpg')

INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(3,'https://www.kudaveceras.rs/images/offers/1435655061-Hotmess_1.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(3,'https://reserve.rs/wp-content/uploads/2015/05/Splav-Hot-Mess-Reserve-2-4.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(3,'http://beowiki.com/wp-content/uploads/2016/03/hot-mass.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(3,'https://belgradeatnight.com/wp-content/uploads/2016/06/Hot-Mess.jpg')

INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(4,'http://www.dvajelena.rs/files/images/2015/8/14/IMG_4634.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(4,'https://www.restoranibeograd.com/storage/restaurant/interior/19/restoran_dva_jelena_12.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(4,'https://www.gdeizaci.com/upload/Place/InteriorGalleries/2017-02/restoran_dva_jelena_13.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(4,'http://www.dvajelena.rs/files/images/2015/8/14/IMG_2940.jpg')

INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(5,'http://www.nekretninesrbije.com//images/realestates/image4c3b1410b0d9e.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(5,'https://media-cdn.tripadvisor.com/media/photo-s/04/31/eb/d8/mali-vrabac.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(5,'http://belgrad-stadtbesichtigung.com//img/tip.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(5,'http://www.mirandre.com/psn/83/50/restoran-mali-vrabac-restoran-vrabac-5928-11516184844677.jpg')

INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(6,'https://www.svetrestorana.rs/files/f156_15493489_1498241923538582_4128926812217422419_o.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(6,'https://www.gdeizaci.com/upload/Place/InteriorGalleries/2017-04/restoran_frans_13.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(6,'http://beowiki.com/wp-content/uploads/2016/02/restoran_frans_beograd_10.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(6,'http://www.frans.rs/wp-content/uploads/2015/05/restoran-7-1024x680.jpg')

INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(7,'http://www.boutiquerestoran.com/images/galerija/restoran-boutique-galerija-01.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(7,'http://www.boutiquerestoran.com/images/galerija/restoran-boutique-galerija-13.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(7,'http://www.boutiquerestoran.com/images/galerija/restoran-boutique-galerija-03.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(7,'http://www.dokmanovich.rs/img/products/boutique2/boutique2-2.jpg')

INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(8,'https://www.beogradnocu.com/wp-content/uploads/2016/05/Bar-Cross-enterijer7.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(8,'https://www.beogradnocu.com/wp-content/uploads/2016/05/Bar-Cross-enterijer2.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(8,'http://ebl.rs/wp-content/uploads/2016/05/BB7_2842_resize.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(8,'http://ebl.rs/wp-content/uploads/2016/05/BB7_2838_resize.jpg')

INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(9,'https://www.gdeizaci.com/upload/Place/InteriorGalleries/2015-12/industrija_bar_1_2.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(9,'https://www.kudaveceras.rs/images/offers/1446210584-Industrija_Bar_Beograd_(2).jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(9,'https://www.beogradnocu.com/wp-content/uploads/2014/04/DSC_0036-10.jpg')
INSERT INTO [dbo].[Image]([LocaleId],[Path])
VALUES(9,'https://www.gdeizaci.com/upload/Place/InteriorGalleries/2015-12/idustrija_bar_24.jpg')

GO


